/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package phonedirectory;

/**
 *
 * @author hasan
 */
public interface HashTable {

    public abstract void insert(DoublyLinkedList d);

    public abstract String display();

    public abstract String update(String str, String UpdatedNumber );

    public abstract String delete(String str, DoublyLinkedList list);

    public abstract String find(String str);

}
