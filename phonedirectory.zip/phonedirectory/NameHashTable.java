/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package phonedirectory;

import java.util.Scanner;

/**
 *
 * @author hasan
 */
public class NameHashTable implements HashTable {

    Contact[] NameTable;

    /*hashtable for name*/
    public NameHashTable(int size) {
        int primeSize = size + (size / 3);
        NameTable = new Contact[primeSize];
        for (int i = 0; i < NameTable.length; i++) {
            NameTable[i] = new Contact();
        }
    }

    public int toInt(String symbol) {
        int sum = 0, i = 0;
        while (i < symbol.length()) {
            int ch = (int) symbol.charAt(i);
            sum = sum + ch;
            i++;
        }
        return sum;
    }

    public int Hash(String symbol) {
        int hashVal = (toInt(symbol)) % NameTable.length;
        return hashVal;
    }

    @Override
    public void insert(DoublyLinkedList list) {
        Node Temp = list.head;
        int i = 0;
        while (Temp != null) {
            String name = Temp.myContact.name;
            int hashVal = Hash(name);
            if (NameTable[hashVal] == null) {
                NameTable[hashVal] = Temp.myContact;
            } else {
                while (NameTable[hashVal] != null && i < NameTable.length) {
                    hashVal = (hashVal + (i + 1)) % NameTable.length;
                    i++;
                }
                NameTable[hashVal] = Temp.myContact;
            }
            Temp = Temp.next;
        }
    }

    @Override
    public String display() {
       String str="";
        //System.out.println("NameTable: ");
        for (int i = 0; i < NameTable.length; i++) {
            if (NameTable[i] == null) {
            } else {
                 if(NameTable[i].name !=null)
                str=" Contact Name: "+NameTable[i].name+" Phone No: "+NameTable[i].phoneNumber+"\n"+str;
            }
        }
        return str;
    }

    @Override
    public String find(String name) {
    String str="";
    //hash function on name.
        // arr[hash].mycontact.name==name, if equal display contact. else rehash function called.
        // until arr[rehash].name==name
        int hash = Hash(name);
        if(NameTable[hash].name !=null){
        if (NameTable[hash].name.compareToIgnoreCase(name)==0) {
            //System.out.println(" Contact found ");
             str=str+" Name: "+NameTable[hash].name+" , "+" PhoneNumber: "+NameTable[hash].phoneNumber;
             
        } else {
           int i = 0;
            while (i < NameTable.length && (NameTable[hash].name.compareToIgnoreCase(name) !=0)) {
                hash = (hash + (i + 1)) % NameTable.length;
                i++;
                }
            if ((NameTable[hash].name.compareToIgnoreCase(name) ==0)) {
               str=str+" Name: "+NameTable[hash].name+" , "+" PhoneNumber: "+NameTable[hash].phoneNumber;
                
            } else {
               // System.out.println(" Contact found ");
                str=" Contact Not Found! ";
            }
        }
        }
        else{
            str=" Contact not found! ";
        }
        return str;
    }
    
        
        
    

    @Override
    public String delete(String name, DoublyLinkedList list) {
        String str="";
// find name in hashtable. 
        int hash = Hash(name);
        if(NameTable[hash].name !=null){
        if (NameTable[hash].name.compareToIgnoreCase(name) ==0) {
            NameTable[hash] = null;
            //str=display();
           
        } else {
            int i = 0;
           
            while (i < NameTable.length &&  NameTable[hash].name !=null && (NameTable[hash].name.compareToIgnoreCase(name)) !=0) {
                hash = (hash + (i + 1)) % NameTable.length;
                i++;
            }
            if (i == NameTable.length) {
                str=" Contact Not Found, can not delete. ";
            } else {
                NameTable[hash] = null;
                //str=display();
            }
        }
        }
        else{
            str=" Contact not present, hence cannot delete! ";
        }
        return str;
    }

    @Override
    public String update(String name,String updatedNo) {
        String str="";
        int hash = Hash(name);
        if(NameTable[hash].name !=null){
        if (NameTable[hash].name.compareToIgnoreCase(name)==0) {
            System.out.println(" Update your phone no ");
             NameTable[hash].phoneNumber = updatedNo;
                 str=str+" Name: "+NameTable[hash].name+" , "+" PhoneNumber: "+NameTable[hash].phoneNumber;
        } else {
            int i = 0;
            while (i < NameTable.length && !(NameTable[hash].name.equals(name))) {
                hash = (hash + (i + 1)) % NameTable.length;
                i++;
            }
            if (i == NameTable.length) {
                System.out.println(" Not Found ");
            } else {
                NameTable[hash].phoneNumber = updatedNo;
                 str=str+" Name: "+NameTable[hash].name+" , "+" PhoneNumber: "+NameTable[hash].phoneNumber;
                
            }
        }
        }
        else{
            str=" Contact not found! ";
        }
        return str;
    }
    
     public String ReturnNameTable(){
        String str="";
        for(int i=0; i<NameTable.length; i++){
            if(NameTable[i]==null){
                
            }
            else{
                if(NameTable[i].name !=null)
                str=" Contact Name:"+NameTable[i].name+" Phone No: "+NameTable[i].phoneNumber+"\n"+str;
            }
        }
        return str;
    }

}
