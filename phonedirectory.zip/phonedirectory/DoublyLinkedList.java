/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package phonedirectory;

/**
 *
 * @author hasan
 */
public class DoublyLinkedList {

    Node head;

    public void insertAtHead(String name, String number) {
        Node newNode = new Node(name, number);
        if (head == null) {
            head = newNode;
        } else {
            newNode.next = head;
            head.prev = newNode;
            head = newNode;
        }
    }

    public String display(DoublyLinkedList list) {
        Node Temp = list.head;
        String str="";
        while (Temp != null) {
            str= str+"\n"+" Name: "+Temp.myContact.name+" Phone Number: "+Temp.myContact.phoneNumber;
            Temp = Temp.next;
        }
        return str;
    }

    public String delete(String name, DoublyLinkedList list) {
        String str="";
        Node Temp = list.head;
        while (Temp != null && Temp.myContact.name.compareTo(name) != 0) {
            Temp = Temp.next;
        }
        if (Temp != null && Temp.myContact.name.compareTo(name) == 0) {
            if (Temp == head) {// found data at firsr node 
                head = Temp.next;
                Temp.next.prev = null;
            } else if (Temp.next == null) {// found data at last node.
                Temp.prev.next = null;
            } else {// delete middle node
                Node Temp1 = Temp.prev;
                Temp.prev.next = Temp.next;
                Temp.next.prev = Temp1;
            }
             str=list.display(list);
        } else {
            str="Data Not found, Cannot delete! ";
            }
               return str;
    }

}
